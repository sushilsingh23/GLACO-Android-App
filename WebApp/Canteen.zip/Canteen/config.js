module.exports={
	env:'dev',
	applicationUrl: 'http://localhost:3000',
	port:{
		http:7860,
		https:443
	},
	logginMode :'error',
	redisConfig:{
		host:'127.0.0.1',
		port:6379
	},
	databaseConnection :{
		connectionLimit:100,
		host:'127.0.0.1',

		user :'root',
		password :'pir@ate',
		database: 'canteen'
	},
	enableGoogleAnalyticsTracking:false
};
