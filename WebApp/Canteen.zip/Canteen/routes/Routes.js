var Router= require('koa-router');
var bodyParser = require('koa-body')();

module.exports = function(app){

    var router = new Router();

    // Home Routes
   var homeCtrl = require('./../controllers/HomeCtrl');
   router.get('/order',homeCtrl.showOrderPage);
   router.get('/orderdetails',homeCtrl.showOrderDetailsPage);
   router.get('/studentdetails',homeCtrl.showStudentDetailsPage);
   router.get('/paymentdetails',homeCtrl.showPaymentDetailsPage);
   router.get('/dashboard',homeCtrl.showDashboardPage);
    router.get('/orders',homeCtrl.showOrdersPage);


    // Login Routes
    var loginCtrl = require('./../controllers/LoginCtrl');

    router.get('/login', loginCtrl.showLoginPage);
    router.get('/signup', loginCtrl.showSignupPage);
    router.get('/logout', loginCtrl.logout);

    router.post('/index',bodyParser, loginCtrl.login);

    // User Routes
    // var UserCtrl = require('./../controllers/User');


    // Post Routes
    //var postCtrl = require('./../controllers/PostCtrl');




    return router.middleware();
}
