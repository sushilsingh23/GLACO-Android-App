module.exports = {
    redisDataKeys: {
      CATEGORY_LIST: "categoryList"

    },
    productStatus: {
        INACTIVE: 1,
        ACTIVE: 2,
        SOLD: 3
    },

loginError:{
  INCORRECT_CREDENTIALS: "Incorrect User credentials"
}
};
