var redisUtils = require('./redisUtils');
var uuid = require('uuid');
var thunkify = require('thunkify');

module.exports = {
    saveUserInSession: function(user, cookies) {
        var sessionId = uuid.v1();  // uuid: uniqe id every time
        var sessionObj = {user: user};
        redisUtils.setItemWithExpiry(sessionId,  JSON.stringify(sessionObj), 86400);    // 86400: for 1 day
        cookies.set("SESSION_ID", sessionId);
    },

    // saveAdminInSession: function(admin, cookies) {
    //     var sessionId = uuid.v1();  // uuid: uniqe id every time
    //     var sessionObj = {admin: admin};
    //     redisUtils.setItemWithExpiry(sessionId,  JSON.stringify(sessionObj), 86400);    // 86400: for 1 day
    //     cookies.set("SESSION_ID", sessionId);
    // },

    updateUserInSession: function(user, cookies) {
        var sessionId = cookies.get("SESSION_ID");
        var sessionObj = {user: user};
        redisUtils.setItemWithExpiry(sessionId, 86400,  JSON.stringify(sessionObj));
    },

    // updateAdminInSession: function(admin, cookies) {
    //     var sessionId = cookies.get("SESSION_ID");
    //     var sessionObj = {admin: admin};
    //     redisUtils.setItemWithExpiry(sessionId, 86400,  JSON.stringify(sessionObj));
    // },

    getCurrentUser: thunkify(function(sessionId, callback) {
        var currentUser;
        if(sessionId) {
            redisUtils.getItemWithCallback(sessionId, function(err, res) {
                if(err) {
                    logger.logError(err);
                }
                if(res == null) {
                    callback(currentUser);
                } else {
                    callback(err, JSON.parse(res).user);
                }
            });
        } else {
            callback(currentUser);
        }
    }),

    // getCurrentAdmin: thunkify(function(sessionId, callback) {
    //     var currentAdmin;
    //     if(sessionId) {
    //         redisUtils.getItemWithCallback(sessionId, function(err, res) {
    //             if(err) {
    //                 logger.logError(err);
    //             }
    //             if(res == null) {
    //                 callback(currentAdmin);
    //             } else {
    //                 callback(err, JSON.parse(res).admin);
    //             }
    //         });
    //     } else {
    //         callback(currentAdmin);
    //     }
    // }),

    deleteSession: function(sessionId) {
        redisUtils.deleteItem(sessionId, function(err, reply) {
            if(err) {
                logger.logError(err);
            }
        });
    }

    // deleteSession: function(sessionId) {
    //     redisUtils.deleteItem(sessionId, function(err, reply) {
    //         if(err) {
    //             logger.logError(err);
    //         }
    //     });
    // }
}
