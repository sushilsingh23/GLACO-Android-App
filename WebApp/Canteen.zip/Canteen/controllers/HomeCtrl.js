var sessionUtils = require('./../services/sessionUtils');
var Constants = require('./../constants');
var config = require('./../config');
var databaseUtils = require('./../services/databaseUtils');
var redisUtils = require('./../services/redisUtils');
var util = require('util');

module.exports = {

    showHomePage: function* (next){

      yield this.render('index', {

      });
    },

    showOrdersPage: function* (next){

      yield this.render('orderPage', {

      });
    },

    showOrderPage: function* (next){

      yield this.render('order', {
        // this.body="order";
      });
    },

    showOrderDetailsPage: function*(next){
      yield this.render('orderDetails');
    },

    showStudentDetailsPage: function*(next){
      yield this.render('studentDetails');
    },

    showPaymentDetailsPage: function*(next){
      yield this.render('paymentDetails');
    },

    showDashboardPage: function*(next){
      yield this.render('dashboard');
    },


    // showStudentDetailsPage: function*(next){
    //   yield this.render('studentDetails');
    // },

}
