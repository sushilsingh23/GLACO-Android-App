var sessionUtils = require('./../services/sessionUtils');
var Constants = require('./../constants');
var config = require('./../config');
var databaseUtils = require('./../services/databaseUtils');
var redisUtils = require('./../services/redisUtils');
var util = require('util');

module.exports = {

  showSignupPage: function* (next){
    yield this.render('signup', {});
  },

  showLoginPage: function* (next){
    yield this.render('login', {});
  },

  login: function* (next){
    var email = this.request.body.uemail;
    var password = this.request.body.pswd;
    // console.log(username+password)
    var queryString = "select * from user where email = '%s' and password = '%s'";
    var query = util.format(queryString, email, password);
    var results = yield databaseUtils.executeQuery(query);
console.log(query);

    var errorMessage;
    if(results.length == 0) {
        errorMessage = "Incorrect user credentials";
        yield this.render('index', {
            errorMessage: errorMessage
        });
    } else {
        var redirectUrl = "/app/orders";
        sessionUtils.saveUserInSession(results[0], this.cookies);
        this.redirect(redirectUrl);
    }
    // console.log();
  },

  signup: function *(next) {
    var username = this.request.body.uname;
    var email = this.request.body.email;
    var password  = this.request.body.pswd;
    var repassword  = this.request.body.repswd;
    var mobile = this.request.body.mobile;
    // console.log(username);
    var queryString = "select * from user where email = '%s' or username = '%s' ";
    var query = util.format(queryString, email, username);
    var userDetails = yield databaseUtils.executeQuery(query);

    // console.log(userDetails.length);
    if(userDetails.length == 0){
      try{
      queryString = "insert into user(username , password , email , mobile, rid) values('%s','%s','%s','%s',2)";
      query = util.format(queryString, username, password, email, mobile);
      var user = yield  databaseUtils.executeQuery(query);

      }
      catch(e){
        console.log(e);
      }
      var uId = user.insertId;
      // console.log(uId);
      var redirectUrl = "/app/index";
      this.redirect(redirectUrl);
    }
    else {
      errorMessage = Constants.SIGNUP_EMAIL_ERROR;
      yield this.render('index', {
        errorMessage: errorMessage,
      });
    }

    // this.body = "done";
  },


  logout: function* (next) {
    var sessionId = this.cookies.get("SESSION_ID");
    if(sessionId) {
      sessionUtils.deleteSession(sessionId);
    }
    this.cookies.set("SESSION_ID", '', {expires: new Date(1), path: '/'});
    this.body = "You are logged out from session"
    this.redirect('/app/login');

  },

  setting: function *(next){
    var oldpswd = this.request.body.oldpswd;
    var newpswd = this.request.body.newpswd;
    var newrepswd = this.request.body.newrepswd;
    // var currentUser;
// console.log(this.currentUser);
    // console.log(oldpswd+", "+newpswd+", "+newrepswd);
    var queryString = "update user set password = '%s' where email ='%s'";
    var query = util.format(queryString, newpswd, this.currentUser.email);
    yield databaseUtils.executeQuery(query);

    this.redirect('/app/categories');
    // this.body="<script type="javascript">alert("passwoe")</script>";
  }
}
